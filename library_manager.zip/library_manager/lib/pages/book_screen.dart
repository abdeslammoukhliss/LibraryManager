import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:library_manager/pages/drawer_widget.dart';

import '../models/book.dart';
import 'add_book_screen.dart';
import 'book_details_screen.dart';
import 'edit_book_screen.dart';

class BooksScreen extends StatefulWidget {
  @override
  _BooksScreenState createState() => _BooksScreenState();
}

class _BooksScreenState extends State<BooksScreen> {
  final List<Book> books = [
    Book(
        title: 'Book One',
        author: 'Author One',
        imagePath: 'assets/book1.jpeg',
        description: "simple description"),
    Book(
        title: 'Book Two',
        author: 'Author Two',
        imagePath: 'assets/book2.jpg',
        description: "simple desctiption"),
  ];
  void _addBook(Book book) {
    setState(() {
      books.add(book);
    });
  }

  void _deleteBook(int index) {
    setState(() {
      books.removeAt(index);
    });
  }
  void _editBook(int index, Book book) {
    setState(() {
      books[index] = book;
    });
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: DrawerWidget(),
      appBar: AppBar(
        title: Text('Livres'),
      ),
      body: ListView.builder(
        itemCount: books.length,
        itemBuilder: (context, index) {
          final book = books[index];
          Image image = Image.asset("assets/book1.jpeg",
              width: 50, height: 50, fit: BoxFit.cover);
          try {
            image = Image.asset(book.imagePath,
                width: 50, height: 50, fit: BoxFit.cover);
          } catch (e) {
            image = Image.asset("assets/book1.jpeg",
                width: 50, height: 50, fit: BoxFit.cover);
          }
          return Card(
            child: ListTile(
              leading: image,
              title: Text(book.title),
              subtitle: Text(book.author),
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => BookDetailScreen(book: book),
                  ),
                );
              },
              trailing: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Icon(Icons.edit),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => EditBookScreen(
                            book: book,
                            editBookCallback: _editBook, index: index,
                          ),
                        ),
                      );
                    },
                  ),
                    IconButton(
                      icon: Icon(Icons.delete,color: Colors.red,),
                      onPressed: () {
                        _deleteBook(index);
                      },
                    ),
                ],
              ),
            ),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => AddBookScreen(addBookCallback: _addBook),
            ),
          );
        },
        child: Icon(Icons.add),
      ),
    );
  }
}
